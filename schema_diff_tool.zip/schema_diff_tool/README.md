# PostgreSQL Schema Diff Tool

Compares the schema of two PostgreSQL databases (an "old" one and a "new"
one) — tables, columns, constraints and indexes — and produces:

- `reports/schema_diff.json` — machine-readable diff
- `reports/schema_diff.html` — a color-coded, human-readable report you can open in a browser

Everything lives in a single script, `schema_diff.py`. No credentials or
paths are hard-coded — all configuration comes from environment variables,
loaded from a `.env` file.

## 1. Requirements

- Python 3.9+
- Two PostgreSQL databases you have read access to (or one database with
  two schemas/snapshots you want to compare)

## 2. Setup

```bash
pip install -r requirements.txt
cp .env.example .env
```

Edit `.env` and fill in your real connection details:

```env
OLD_DB_HOST=localhost
OLD_DB_PORT=5432
OLD_DB_NAME=schema_old
OLD_DB_USER=postgres
OLD_DB_PASSWORD=your_password

NEW_DB_HOST=localhost
NEW_DB_PORT=5432
NEW_DB_NAME=schema_new
NEW_DB_USER=postgres
NEW_DB_PASSWORD=your_password

PG_SCHEMA=public
REPORTS_DIR=reports
```

`.env` is only an example of what to name your file — **never commit your
real `.env` to version control.**

## 3. Run it

```bash
python schema_diff.py
```

Console output looks like:

```
Connecting to old database: schema_old@localhost
Connecting to new database: schema_new@localhost
Reading schema 'public' from old database...
Reading schema 'public' from new database...
Comparing schemas...
JSON report written to reports/schema_diff.json
HTML report written to reports/schema_diff.html

Summary:
  TABLE_ADDED: 1
  COLUMN_ADDED: 1
  COLUMN_CHANGED: 2
  CONSTRAINT_ADDED: 1
  INDEX_ADDED: 1
```

Then open `reports/schema_diff.html` in your browser to see the full
color-coded report (green = added, red = removed, yellow = changed).

## 4. Quick test with sample data

Create two throwaway databases, `schema_old` and `schema_new`, point your
`.env` at them, and run this in `schema_old`:

```sql
CREATE TABLE public.stages (
    id INTEGER PRIMARY KEY,
    name VARCHAR(50) NOT NULL
);

CREATE TABLE public.pcb (
    id SERIAL PRIMARY KEY,
    serial_number VARCHAR(50)
);
```

And this in `schema_new`:

```sql
CREATE TABLE public.stages (
    id INTEGER PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

CREATE TABLE public.pcb (
    id SERIAL PRIMARY KEY,
    serial_number VARCHAR(100),
    stage_id INTEGER REFERENCES public.stages(id)
);

CREATE INDEX idx_pcb_serial ON public.pcb(serial_number);

CREATE TABLE public.machine_alerts (
    id SERIAL PRIMARY KEY,
    alert_type TEXT
);
```

Run `python schema_diff.py` again. You should see:

| Object              | Expected result                |
|---------------------|---------------------------------|
| `machine_alerts`    | Table added                     |
| `pcb.stage_id`       | Column added                    |
| `pcb.serial_number`  | Length changed from 50 to 100   |
| `stages.name`        | Length changed from 50 to 100   |
| `pcb` foreign key    | Constraint added                |
| `pcb` index          | Index added                     |

If these all show up, the comparison engine is working correctly.

## 5. What it compares

- **Tables** — added / removed
- **Columns** — added / removed / changed (type, length, nullability, default)
- **Constraints** — primary keys, foreign keys, unique and check constraints (added / removed / changed)
- **Indexes** — added / removed / changed definitions

## 6. Important notes

- This tool is an **inspection tool, not a migration script**. It tells you
  what's different — it does not generate or run `ALTER TABLE` statements.
  Review any changes and their SQL implications before touching a live
  database.
- Renamed columns/tables currently show up as a removal + an addition,
  since the tool matches objects by name only. Detecting true renames needs
  extra heuristics or migration history.
- Views, functions and triggers are not compared (would require additional
  queries against `pg_views`, `pg_proc`, `pg_trigger`, etc.).
- `information_schema.columns` can represent some PostgreSQL types less
  precisely than the internal catalogs. For exact type/collation
  comparisons, a future version could query `pg_attribute` and `pg_type`
  directly.

## 7. Possible next steps

1. Detect renamed columns/tables (heuristics or explicit migration history)
2. Compare views, functions and triggers
3. Auto-generate migration SQL (`ALTER TABLE`, `CREATE INDEX`, etc.) — with
   mandatory review before applying anything destructive
4. Wrap this in a small web UI (e.g. upload two SQL dumps, run the
   comparison in an isolated environment, browse results in a dashboard)

## 8. Files

```
.
├── schema_diff.py       # the entire tool (extraction, comparison, JSON + HTML report)
├── .env.example         # template for your configuration — copy to .env
├── requirements.txt     # psycopg2-binary, python-dotenv
├── README.md            # this file
└── reports/             # generated output (schema_diff.json / schema_diff.html)
```
