"""
schema_diff.py

Compares the schema (tables, columns, constraints, indexes) of two
PostgreSQL databases ("old" and "new") and produces:

  - reports/schema_diff.json  -> machine-readable diff
  - reports/schema_diff.html  -> human-readable diff report

All connection details and settings are read from a `.env` file
(see `.env.example`). Nothing is hard-coded in this file.

Usage:
    pip install -r requirements.txt
    cp .env.example .env   # then edit .env with your real values
    python schema_diff.py
"""

import html
import json
import os
from pathlib import Path

import psycopg2
import psycopg2.extras
from dotenv import load_dotenv

# --------------------------------------------------------------------------
# 0. Configuration (all values come from environment / .env, nothing hard-coded)
# --------------------------------------------------------------------------

load_dotenv()


def _require_env(name: str, default: str | None = None) -> str:
    value = os.getenv(name, default)
    if value is None or value == "":
        raise RuntimeError(
            f"Missing required environment variable: {name}. "
            f"Check your .env file (see .env.example)."
        )
    return value


OLD_DB = {
    "host": _require_env("OLD_DB_HOST"),
    "port": _require_env("OLD_DB_PORT", "5432"),
    "dbname": _require_env("OLD_DB_NAME"),
    "user": _require_env("OLD_DB_USER"),
    "password": _require_env("OLD_DB_PASSWORD"),
}

NEW_DB = {
    "host": _require_env("NEW_DB_HOST"),
    "port": _require_env("NEW_DB_PORT", "5432"),
    "dbname": _require_env("NEW_DB_NAME"),
    "user": _require_env("NEW_DB_USER"),
    "password": _require_env("NEW_DB_PASSWORD"),
}

SCHEMA_NAME = os.getenv("PG_SCHEMA", "public")
REPORTS_DIR = Path(os.getenv("REPORTS_DIR", "reports"))
JSON_REPORT_PATH = REPORTS_DIR / os.getenv("JSON_REPORT_NAME", "schema_diff.json")
HTML_REPORT_PATH = REPORTS_DIR / os.getenv("HTML_REPORT_NAME", "schema_diff.html")


# --------------------------------------------------------------------------
# 1. Connection helper
# --------------------------------------------------------------------------

def get_connection(config: dict):
    return psycopg2.connect(
        host=config["host"],
        port=config["port"],
        dbname=config["dbname"],
        user=config["user"],
        password=config["password"],
    )


# --------------------------------------------------------------------------
# 2. Schema extraction
# --------------------------------------------------------------------------

def get_schema(conn, schema_name: str) -> dict:
    """
    Returns a dict describing every table in `schema_name`:

    {
        "table_name": {
            "columns": {
                "col_name": {
                    "type": "character varying",
                    "length": 50,
                    "nullable": "YES"/"NO",
                    "default": "..." or None,
                }
            },
            "constraints": {
                "constraint_name": {
                    "type": "PRIMARY KEY" / "FOREIGN KEY" / "UNIQUE" / "CHECK",
                    "columns": ["col1", "col2"],
                    "foreign_table": "other_table" or None,
                    "foreign_columns": ["col"] or [],
                }
            },
            "indexes": {
                "index_name": "CREATE INDEX ... definition"
            },
        }
    }
    """
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    schema: dict = {}

    # ---- Tables ----
    cur.execute(
        """
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = %s AND table_type = 'BASE TABLE'
        ORDER BY table_name
        """,
        (schema_name,),
    )
    for row in cur.fetchall():
        schema[row["table_name"]] = {
            "columns": {},
            "constraints": {},
            "indexes": {},
        }

    # ---- Columns ----
    cur.execute(
        """
        SELECT table_name, column_name, data_type,
               character_maximum_length, is_nullable, column_default
        FROM information_schema.columns
        WHERE table_schema = %s
        ORDER BY table_name, ordinal_position
        """,
        (schema_name,),
    )
    for row in cur.fetchall():
        table = schema.get(row["table_name"])
        if table is None:
            continue
        table["columns"][row["column_name"]] = {
            "type": row["data_type"],
            "length": row["character_maximum_length"],
            "nullable": row["is_nullable"],
            "default": row["column_default"],
        }

    # ---- Constraints (PK, FK, UNIQUE, CHECK) ----
    cur.execute(
        """
        SELECT
            tc.constraint_name,
            tc.constraint_type,
            tc.table_name,
            kcu.column_name,
            ccu.table_name  AS foreign_table,
            ccu.column_name AS foreign_column
        FROM information_schema.table_constraints tc
        JOIN information_schema.key_column_usage kcu
            ON tc.constraint_name = kcu.constraint_name
            AND tc.table_schema = kcu.table_schema
        LEFT JOIN information_schema.constraint_column_usage ccu
            ON tc.constraint_name = ccu.constraint_name
            AND tc.constraint_type = 'FOREIGN KEY'
            AND tc.table_schema = ccu.table_schema
        WHERE tc.table_schema = %s
        ORDER BY tc.table_name, tc.constraint_name
        """,
        (schema_name,),
    )
    for row in cur.fetchall():
        table = schema.get(row["table_name"])
        if table is None:
            continue
        entry = table["constraints"].setdefault(
            row["constraint_name"],
            {
                "type": row["constraint_type"],
                "columns": [],
                "foreign_table": row["foreign_table"],
                "foreign_columns": [],
            },
        )
        if row["column_name"] and row["column_name"] not in entry["columns"]:
            entry["columns"].append(row["column_name"])
        if row["foreign_column"] and row["foreign_column"] not in entry["foreign_columns"]:
            entry["foreign_columns"].append(row["foreign_column"])

    # ---- Indexes ----
    cur.execute(
        """
        SELECT indexname, tablename, indexdef
        FROM pg_indexes
        WHERE schemaname = %s
        ORDER BY tablename, indexname
        """,
        (schema_name,),
    )
    for row in cur.fetchall():
        table = schema.get(row["tablename"])
        if table is None:
            continue
        table["indexes"][row["indexname"]] = row["indexdef"]

    cur.close()
    return schema


# --------------------------------------------------------------------------
# 3. Comparison
# --------------------------------------------------------------------------

def compare_schemas(old_schema: dict, new_schema: dict) -> dict:
    changes = []

    old_tables = set(old_schema.keys())
    new_tables = set(new_schema.keys())

    for table in sorted(new_tables - old_tables):
        changes.append({"type": "TABLE_ADDED", "table": table})

    for table in sorted(old_tables - new_tables):
        changes.append({"type": "TABLE_REMOVED", "table": table})

    for table in sorted(old_tables & new_tables):
        old_t = old_schema[table]
        new_t = new_schema[table]

        # --- Columns ---
        old_cols = set(old_t["columns"].keys())
        new_cols = set(new_t["columns"].keys())

        for col in sorted(new_cols - old_cols):
            changes.append({"type": "COLUMN_ADDED", "table": table, "column": col})

        for col in sorted(old_cols - new_cols):
            changes.append({"type": "COLUMN_REMOVED", "table": table, "column": col})

        for col in sorted(old_cols & new_cols):
            old_def = old_t["columns"][col]
            new_def = new_t["columns"][col]
            if old_def != new_def:
                changes.append(
                    {
                        "type": "COLUMN_CHANGED",
                        "table": table,
                        "column": col,
                        "old": old_def,
                        "new": new_def,
                    }
                )

        # --- Constraints ---
        old_cons = set(old_t["constraints"].keys())
        new_cons = set(new_t["constraints"].keys())

        for name in sorted(new_cons - old_cons):
            changes.append(
                {
                    "type": "CONSTRAINT_ADDED",
                    "table": table,
                    "name": name,
                    "new": new_t["constraints"][name],
                }
            )

        for name in sorted(old_cons - new_cons):
            changes.append(
                {
                    "type": "CONSTRAINT_REMOVED",
                    "table": table,
                    "name": name,
                    "old": old_t["constraints"][name],
                }
            )

        for name in sorted(old_cons & new_cons):
            old_def = old_t["constraints"][name]
            new_def = new_t["constraints"][name]
            if old_def != new_def:
                changes.append(
                    {
                        "type": "CONSTRAINT_CHANGED",
                        "table": table,
                        "name": name,
                        "old": old_def,
                        "new": new_def,
                    }
                )

        # --- Indexes ---
        old_idx = set(old_t["indexes"].keys())
        new_idx = set(new_t["indexes"].keys())

        for name in sorted(new_idx - old_idx):
            changes.append(
                {
                    "type": "INDEX_ADDED",
                    "table": table,
                    "name": name,
                    "new": new_t["indexes"][name],
                }
            )

        for name in sorted(old_idx - new_idx):
            changes.append(
                {
                    "type": "INDEX_REMOVED",
                    "table": table,
                    "name": name,
                    "old": old_t["indexes"][name],
                }
            )

        for name in sorted(old_idx & new_idx):
            if old_t["indexes"][name] != new_t["indexes"][name]:
                changes.append(
                    {
                        "type": "INDEX_CHANGED",
                        "table": table,
                        "name": name,
                        "old": old_t["indexes"][name],
                        "new": new_t["indexes"][name],
                    }
                )

    summary: dict = {}
    for change in changes:
        summary[change["type"]] = summary.get(change["type"], 0) + 1

    return {
        "summary": summary,
        "changes": changes,
    }


# --------------------------------------------------------------------------
# 4. Report generation
# --------------------------------------------------------------------------

def write_json_report(report: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")


def generate_html_report(report: dict, path: Path, old_label: str, new_label: str) -> None:
    rows = []

    for change in report["changes"]:
        change_type = change["type"]

        if "ADDED" in change_type:
            color = "#dcfce7"
        elif "REMOVED" in change_type:
            color = "#fee2e2"
        else:
            color = "#fef3c7"

        rows.append(
            f"""
            <tr style="background:{color}">
                <td>{html.escape(change_type)}</td>
                <td>{html.escape(change.get("table", ""))}</td>
                <td>{html.escape(change.get("column", change.get("name", "")))}</td>
                <td><pre>{html.escape(str(change.get("old", "")))}</pre></td>
                <td><pre>{html.escape(str(change.get("new", "")))}</pre></td>
            </tr>
            """
        )

    summary = "".join(
        f"<li>{html.escape(k)}: {v}</li>" for k, v in report["summary"].items()
    )

    page = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>PostgreSQL Schema Diff</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            margin: 30px;
        }}
        table {{
            border-collapse: collapse;
            width: 100%;
        }}
        th, td {{
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
            vertical-align: top;
        }}
        th {{
            background: #1f2937;
            color: white;
        }}
        pre {{
            white-space: pre-wrap;
            max-width: 350px;
        }}
    </style>
</head>
<body>
    <h1>PostgreSQL Schema Comparison</h1>
    <p>Old: {html.escape(old_label)} | New: {html.escape(new_label)}</p>

    <h2>Summary</h2>
    <ul>{summary}</ul>

    <h2>Detailed Changes</h2>
    <table>
        <tr>
            <th>Change</th>
            <th>Table</th>
            <th>Column / Object</th>
            <th>Old Definition</th>
            <th>New Definition</th>
        </tr>
        {''.join(rows)}
    </table>
</body>
</html>
"""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(page, encoding="utf-8")


# --------------------------------------------------------------------------
# 5. Main
# --------------------------------------------------------------------------

def main() -> None:
    print(f"Connecting to old database: {OLD_DB['dbname']}@{OLD_DB['host']}")
    old_conn = get_connection(OLD_DB)

    print(f"Connecting to new database: {NEW_DB['dbname']}@{NEW_DB['host']}")
    new_conn = get_connection(NEW_DB)

    try:
        print(f"Reading schema '{SCHEMA_NAME}' from old database...")
        old_schema = get_schema(old_conn, SCHEMA_NAME)

        print(f"Reading schema '{SCHEMA_NAME}' from new database...")
        new_schema = get_schema(new_conn, SCHEMA_NAME)
    finally:
        old_conn.close()
        new_conn.close()

    print("Comparing schemas...")
    report = compare_schemas(old_schema, new_schema)

    write_json_report(report, JSON_REPORT_PATH)
    print(f"JSON report written to {JSON_REPORT_PATH}")

    generate_html_report(
        report,
        HTML_REPORT_PATH,
        old_label=OLD_DB["dbname"],
        new_label=NEW_DB["dbname"],
    )
    print(f"HTML report written to {HTML_REPORT_PATH}")

    print("\nSummary:")
    for change_type, count in report["summary"].items():
        print(f"  {change_type}: {count}")

    if not report["changes"]:
        print("No schema differences found.")


if __name__ == "__main__":
    main()
